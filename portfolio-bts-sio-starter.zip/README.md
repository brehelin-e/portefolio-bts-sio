# Portfolio – Bréhélin Ewen

Site personnel (BTS SIO – Option SISR).

## Développement
- Ouvrir `index.html` dans le navigateur (double‑clic) pour tester en local.
- Arborescence :
```
/
├─ index.html
├─ assets/
│  ├─ css/style.css
│  └─ img/
└─ js/main.js
```

## Déploiement (GitHub Pages)
- Paramètres du dépôt → **Pages** → Source : *Deploy from a branch*, Branch : `main`, Dossier : `/root`.
- L’URL sera `https://<ton-user>.github.io/portfolio-bts-sio/`.

## À faire
- Remplacer le bouton CV par votre PDF (nommez-le `CV.pdf` à la racine).
- Ajouter des projets avec captures et liens GitHub.
